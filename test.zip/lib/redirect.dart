import 'package:flutter/material.dart';

class Redirect extends StatelessWidget {
  const Redirect({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Redirect"),
        centerTitle: true,
        ),
        body: Center(
          child: ElevatedButton(
            onPressed: (){
              Navigator.pop(context);
            }, 
            child: Text("Redirect")),
        ),
    );
  }
}